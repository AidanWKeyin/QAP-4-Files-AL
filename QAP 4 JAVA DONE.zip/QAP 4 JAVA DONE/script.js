// Script for the marina invoice 
// Author: Aidan lake 
// Dates: Mon, Nov 25 

// Define Constants
const EVEN_SITE = 80.0;
const ODD_SITE = 120.0;
const ALT_MEM = 5.0;
const CLEAN_PER_MONTH = 50.0;
const SURV_PER_MONTH = 35.0;
const HST_RATE = 0.15;
const MONTHLY_DUE_STAND = 75.0;
const MONTHLY_DUE_EXEC = 150.0;
const PROCESS_FEE = 59.99;
const CANCEL_RATE = 0.6;

// Gather user inputs
const currentDate =prompt("Enter the current day (YYYY-MM-DD):");
const siteNum = parseInt(prompt("Enter the current Site Number (1-100):"));
const memName = prompt("Enter the member's name:");
const streetAdd = prompt("Enter the street address:");
const city = prompt("Enter the city:");
const prov = prompt("Enter the province (AA):");
const posCode = prompt("Enter the postal code (A0A-0A0):");
const phoneNum = prompt("Enter the phone number (000-000-0000):");
const cellNum = prompt("Enter the cell number (000-000-0000):");
const memType = prompt("Enter the membership type (S / E):").toUpperCase();
const numAltMem = parseInt(prompt("Enter the number of Family members With access (0-99):"));
const weeklyClean = prompt("Enter if weekly clean is wanted (Y / N):").toUpperCase();
const videoSurv = prompt("Enter if video surveillance is wanted (Y / N):").toUpperCase();


// Perform calculations
const siteCost = siteNum % 2 === 0 ? EVEN_SITE : ODD_SITE;
const siteCharges = siteCost + numAltMem * ALT_MEM;

let extraCharges = 0;
if (weeklyClean === "Y") extraCharges += CLEAN_PER_MONTH;
if (videoSurv === "Y") extraCharges += SURV_PER_MONTH;

const subTotal = siteCharges + extraCharges;
const HST = subTotal * HST_RATE;
const totMonthCharge = subTotal + HST;
const monthlyDue = memType === "S" ? MONTHLY_DUE_STAND : MONTHLY_DUE_EXEC;
const totMonthlyFee = totMonthCharge + monthlyDue;
const totYearlyFee = totMonthlyFee * 12;
const monthlyPayment = (totYearlyFee + PROCESS_FEE) / 12;
const yearlySiteCharges = siteCharges * 12;
const cancelFee = yearlySiteCharges * CANCEL_RATE;

// Java script - HTML 
document.getElementById("clientname").innerText = memName;
document.getElementById("clientaddress").innerText = `${streetAdd}, ${city}, ${prov} ${posCode}`;
document.getElementById("clientcontact").innerText = `Phone: ${phoneNum} (H) ${cellNum} (C)`;
document.getElementById("sitenumber").innerText = siteNum;
document.getElementById("membershiptype").innerText = memType === "S" ? "Standard" : "Executive";
document.getElementById("alternatemembers").innerText = numAltMem;
document.getElementById("weeklycleaning").innerText = weeklyClean === "Y" ? "Yes" : "No";
document.getElementById("videosurveillance").innerText = videoSurv === "Y" ? "Yes" : "No";
document.getElementById("sitecharges").innerText = `$${siteCharges.toFixed(2)}`;
document.getElementById("extracharges").innerText = `$${extraCharges.toFixed(2)}`;
document.getElementById("subtotal").innerText = `$${subTotal.toFixed(2)}`;
document.getElementById("HST").innerText = `$${HST.toFixed(2)}`;
document.getElementById("totalmonthlycharges").innerText = `$${totMonthCharge.toFixed(2)}`;
document.getElementById("monthlydues").innerText = `$${monthlyDue.toFixed(2)}`;
document.getElementById("totalmonthlyfees").innerText = `$${totMonthlyFee.toFixed(2)}`;
document.getElementById("totalyearlyfees").innerText = `$${totYearlyFee.toFixed(2)}`;
document.getElementById("monthlypayment").innerText = `$${monthlyPayment.toFixed(2)}`;
document.getElementById("issueddate").innerText = currentDate;
document.getElementById("cancellationfee").innerText = `$${cancelFee.toFixed(2)}`;
